package co.appreactor.pokedex.modelo.entidades;

import java.util.ArrayList;

/**
 * Created by lord_nightmare on 19/10/17.
 */

public class PokemonRespuesta {

    private ArrayList<Pokemon> resultados;


    public ArrayList<Pokemon> getResultados() {
        return resultados;
    }

    public void setResultados(ArrayList<Pokemon> resultados) {
        this.resultados = resultados;
    }
}
